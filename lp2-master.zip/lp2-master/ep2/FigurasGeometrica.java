public class FigurasGeometrica{
	public void Perimetro(){
	}
	public void Area(){
}
}
